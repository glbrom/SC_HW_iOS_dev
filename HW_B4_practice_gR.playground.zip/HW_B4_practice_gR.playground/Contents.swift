import UIKit

// MARK: - Enum # SC17

/*
 ● В презентации и в playgrounds были приведены варианты перечислений.
 Ключевая идея - каждый case может стать значением enum. Если значениями являются дни недели, то enum должен называться “День недели”. Попробуйте придумать два своих перечисления. Каждый из которых должен соответствовать ключевой идее описанной выше
 ● В первом из ваших enum добавьте RawValue. Укажите его только
 для части case и протестируйте, создав несколько экземпляров этого enum

 ● Во второй enum добавьте функцию, в которой будет switch. Пусть функция возвращает какое-то значение в зависимости от значения enum
 ● Создайте enum с ассоциативными значениями для каждого из его case.
 Протестируйте его, добавив функцию, которая принимает значение enum и возвращаемое значение зависит от принятого, по аналогии с примером из Playgrounds
 */


enum Model: CaseIterable {
    case first_series
    case third_series
    case fives_series
    case x3_series
    case x5_series
    case x6_series

    func carType() -> String {
        switch self {
        case .first_series, .third_series, .fives_series:
            return "Sedan"
        case .x3_series, .x5_series, .x6_series:
            return "SUV"
        }
    }
}

struct BMW {
    var nameBuyer: String
    var model: Model
}

var bob = BMW(nameBuyer: "Bob", model: .x3_series)
print(bob.model)

let arrayModelBMW = Model.allCases
let model = Model.x5_series
let carType = model.carType()



enum Character {
    enum Weapon: Int {
        case ak = 25
        case m4a = 20
        case knight = 1
        case grenade = 50

        var damage: Int {
            return rawValue * 2
        }
    }
}

let charWeapon = Character.Weapon.ak.damage
let charType = Character.Weapon.grenade.damage



indirect enum Pizza {

    case cheese(Ingredients, Ingredients, Ingredients, Ingredients)
    case meat(Ingredients, Ingredients, Ingredients, Ingredients)
    case vegetarian(Ingredients, Ingredients, Ingredients, Ingredients)

    enum Ingredients {
        case tomato
        case cheese
        case mushrooms
        case olives
        case bacon
        case sausage
        case basil
        case arugula
    }
}

let cheesePizza = Pizza.cheese(.cheese, .mushrooms, .basil, .tomato)
let veganPizza = Pizza.vegetarian(.tomato, .basil, .arugula, .mushrooms)
let meatPizza = Pizza.meat(.bacon, .sausage, .tomato, .arugula)



//  Создайте перечисление CalculationType, содержащее четыре математических действия — сложение, вычитание, умножение и деление

enum CalculationType: String {
    case addition = "Addition"
    case subtraction = "Subtraction"
    case multiplication = "Multiplication"
    case division = "Division"
}


//  Напишите функцию возвращающую Int и принимающую в качестве аргументов три переменные: число один, число два и тип математической операции. Внутри функции, в зависимости от значения переменной типа CalculationType выполните соответствующую математическую операцию с константами и верните результат. Для перебора всех возможных результатов используйте конструкцию switch. Присвойте своей функции такое название, что бы из него было понятно для чего служит эта функция, но при этом сделайте это имя максимально лаконичным.

func calculateResult(firstNumber numberOne: Int, secondNumber numberTwo: Int, operation: CalculationType) -> Int {

    var result = numberOne

    switch operation {
    case .addition: result += numberTwo
    case .subtraction: result -= numberTwo
    case .multiplication: result *= numberTwo
    case .division: numberTwo != 0 ? result /= numberTwo : print("Can't divide by zero")
    }

    print("Result \(operation.rawValue) \(numberOne) and \(numberTwo) equals \(result)")
    return result
}


// Вызовите эту функцию четыре раза для каждого математического оператора в отдельности. Постарайтесь сделать реализацию максимально гибкой — такой, что бы результат вывода можно было легко изменить, поменяв значения переменных. Доработайте функцию так, что бы при каждом её вызове на консоль выводился результат следующего содержания: «Результат сложения (вычитания, деления, умножения) <…> и <…> равен <…>» для каждого отдельного случая.


let numberOne = 12
let numberTwo = 3


calculateResult(firstNumber: numberOne, secondNumber: numberTwo, operation: .addition)
calculateResult(firstNumber: numberOne, secondNumber: numberTwo, operation: .division)
calculateResult(firstNumber: numberOne, secondNumber: numberTwo, operation: .multiplication)
calculateResult(firstNumber: numberOne, secondNumber: numberTwo, operation: .subtraction)

let numberThree = 0

calculateResult(firstNumber: numberOne, secondNumber: numberThree, operation: .division)



// MARK: - POP - Protocol Oriented Programming # SC19

/*
 Создаем персонажей для игры:
    ● Создайте enum VehicleType: electric / nonElectric
    ● Создайте протокол Vehicle, который будет включать свойства: weight: Float, speed: Float, type: VehicleType, canFly: Bool. Все перечисленные свойства можно пометить как { get }. И функцию prepare()
    ● Расширьте протокол Vehicle с реализацией функции prepare: если Vehicle electric, выводим в консоль сообщение "Charge", если nonElectric, выводим сообщение "Refuel". Так же задайте значение false для свойства canFly
 */

enum VehicleType {
    case electric
    case nonElectric
}

protocol Vehicle {
    var weight: Float { get }
    var speed: Float { get }
    var type: VehicleType { get }
    var canFly: Bool { get }
    
    func prepare()
}

extension Vehicle {
    var canFly: Bool { return false }
    
    func prepare() {
        switch type {
        case .electric: print("Change")
        case .nonElectric: print("Refuel")
        }
    }
}

/*
    ● Создайте протокол FlyableVehicle c функцией getMaxHight -> Float
    ● Создайте протокол Vehicle для объектов реализующих FlyableVehicle, добавьте по умолчанию для canFly значение true, type - nonElectric. Реализуйте функцию getMaxHight. Если это electric объект, пусть он возвращает weight + speed, если нет, то weight * speed
    ● Создайте структуры Car, ElectricCar, AirPlane и создайте их экземпляры. Внутри структур задавать значения по умолчанию не обязательно, инициализатор будет присутствовать у структур по умолчанию
 */

protocol FlyableVehicle {
    func getMaxHight() -> Float
}


extension Vehicle where Self: FlyableVehicle {
    var canFly: Bool { return true }
    var type: VehicleType { return .nonElectric }

    func getMaxHight() -> Float {
        switch type {
        case .electric: return weight + speed
        case .nonElectric: return weight * speed
        }
    }
}

struct Car: Vehicle {
    var weight: Float
    var speed: Float
    var type: VehicleType
}

struct ElectricCar: Vehicle {
    var weight: Float
    var speed: Float
    var type: VehicleType
}

struct AirPlane: Vehicle, FlyableVehicle {
    var weight: Float
    var speed: Float
    var type: VehicleType

}

let car = Car(weight: 1373, speed: 220, type: .nonElectric)
let electricCar = ElectricCar(weight: 1940, speed: 160, type: .electric)
let airPlane = AirPlane(weight: 5998, speed: 946, type: .nonElectric)


/*
    ● Выведите в консоль свойства у Car и electricalCar: type canFly. У airPlane выведите свойство canFly и вызовите функцию getMaxHight
    ● Создайте структуру ElectricalAirplane, ее экземпляр c теми же данными которые вы использовали для создания обычного самолета. Выведите в консоль значение, которое возвращает функция getMaxHight()
 */

print("свойства у Car: type - \(car.type), canFly - \(car.canFly), и electricalCar: type - \(electricCar.type), canFly - \(electricCar.canFly)")
car.prepare()
electricCar.prepare()


print("свойства у airPlane: canFly - \(airPlane.canFly)")
print("максимальная высота airPlane: \(airPlane.getMaxHight())")


struct ElectricAirplane: FlyableVehicle, Vehicle {
    var weight: Float
    var speed: Float
    var type: VehicleType
}

let electricAirplane = ElectricAirplane(weight: 5998, speed: 946, type: .electric)

print("свойства у electricAirplane: canFly - \(electricAirplane.canFly)")
print("максимальная высота electricAirplane: \(electricAirplane.getMaxHight())")
